<style type="text/css">
	fieldset{
		width: 200px;
		background: #FFECA1;
	}
</style>

<?php
echo "<meta charset=utf-8>";
echo "<center>";
echo "<fieldset>";
echo "<h3> Resultados: </h3>";
echo "Diretamente nas empresas (local ou site) - 24,7%;";
echo "<br>";
echo "<br>";
echo "Através de eventos e sites de recrutamento e/ou voltados a universitários - 19,37%;";
echo "<br>";
echo "<br>";
echo "Procurar a Central de Estágio da faculdade - 19,96%;";
echo "<br>";
echo "<br>";
echo "Indicação de amigos - 30,24%;";
echo "<br>";
echo "<br>";
echo "Criar um site com seu próprio currículo, para ampliar a divulgação de seus objetivos profissionais - 5,73%.";
echo "</fieldset>";
echo "</center>";
?>